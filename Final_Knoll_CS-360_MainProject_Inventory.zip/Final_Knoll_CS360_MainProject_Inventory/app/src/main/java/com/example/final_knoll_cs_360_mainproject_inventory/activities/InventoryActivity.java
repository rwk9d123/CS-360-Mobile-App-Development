package com.example.final_knoll_cs_360_mainproject_inventory.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.final_knoll_cs_360_mainproject_inventory.R;

public class InventoryActivity extends AppCompatActivity {

    Button btn_logout, btn_execute;
    TextView tv_username;
    EditText ti_itemNumber, ti_location, ti_qty;
    Spinner dd_transType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        btn_logout = findViewById(R.id.btn_logout);
        btn_execute = findViewById(R.id.btn_execute);
        tv_username = findViewById(R.id.tf_username);
        ti_itemNumber = findViewById(R.id.ti_itemNumber);
        ti_location = findViewById(R.id.ti_location);
        ti_qty = findViewById(R.id.ni_qty);
        dd_transType = findViewById(R.id.dd_transType);
    }
}