package com.example.final_knoll_cs_360_mainproject_inventory.models;

import java.util.ArrayList;

public class InventoryItem {

    private int itemId;
    private String itemName;
    private int itemQuantity;
    private String itemLocation;

    public InventoryItem(int itemId, String itemName, int itemQuantity, String itemLocation){
        this.itemName = itemName;
        this.itemQuantity = itemQuantity;
        this.itemLocation = itemLocation;
        this.itemId = itemId;

    }

    public int getItemId() {
        return itemId;
    }
    public String getItemName() {
        return itemName;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public String getItemLocation() {
        return itemLocation;
    }

    public void setItemId(int itemId){
        this.itemId = itemId;
    }
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public void setItemLocation(String itemLocation) {
        this.itemLocation = itemLocation;
    }

    public static ArrayList<InventoryItem> getInventoryItems() {

        ArrayList<InventoryItem> inventoryItems = new ArrayList<>();
        inventoryItems.add(new InventoryItem(1,"1/4-20 bolt", 20, "A-1"));
        inventoryItems.add(new InventoryItem(2,"1/4-20 nut", 15, "A-2"));
        inventoryItems.add(new InventoryItem(3,"1/4-20 washer", 50, "A-3"));
        inventoryItems.add(new InventoryItem(4,"5/16-18 bolt", 5, "B-1"));
        inventoryItems.add(new InventoryItem(5,"5/16-18 nut", 3, "B-2"));

        return inventoryItems;
    }
}
