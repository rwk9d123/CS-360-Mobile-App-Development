package com.example.final_knoll_cs_360_mainproject_inventory.activities;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.final_knoll_cs_360_mainproject_inventory.R;

public class MainActivity extends AppCompatActivity {

    EditText userNameExisting, passwordExisting, userNameNew, passwordNew, passwordNewConfirm;
    Button loginButton, createUserButton;

    

    TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {

        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            String usernameString = userNameExisting.getText().toString();
            String passwordString = passwordExisting.getText().toString();
            String usernameNewString = userNameNew.getText().toString();
            String passwordNewUserString = passwordNew.getText().toString();
            String passwordNewUserConfirmString = passwordNewConfirm.getText().toString();


            loginButton.setEnabled(!usernameString.isEmpty() && !passwordString.isEmpty());

            if (!usernameNewString.isEmpty() && !passwordNewUserString.isEmpty() && !passwordNewUserConfirmString.isEmpty()){
                if (passwordNewUserString.equals(passwordNewUserConfirmString)){
                    createUserButton.setEnabled(true);
                }
            }
            else {
                createUserButton.setEnabled(false);
            }




        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        userNameExisting = findViewById(R.id.usernameExisting);
        userNameExisting.addTextChangedListener(textWatcher);
        passwordExisting = findViewById(R.id.passwordExisting);
        passwordExisting.addTextChangedListener(textWatcher);
        userNameNew = findViewById(R.id.usernameNew);
        userNameNew.addTextChangedListener(textWatcher);
        passwordNew = findViewById(R.id.passwordNew);
        passwordNew.addTextChangedListener(textWatcher);
        passwordNewConfirm = findViewById(R.id.passwordNewConfirm);
        passwordNewConfirm.addTextChangedListener(textWatcher);
        loginButton = findViewById(R.id.loginButton);
        createUserButton = findViewById(R.id.createUserButton);

        loginButton.setEnabled(false);
        createUserButton.setEnabled(false);




    }
}