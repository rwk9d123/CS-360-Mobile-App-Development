package com.example.final_knoll_cs_360_mainproject_inventory.db;

import static com.example.final_knoll_cs_360_mainproject_inventory.models.InventoryItem.*;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;

import com.example.final_knoll_cs_360_mainproject_inventory.models.InventoryItem;

import java.util.ArrayList;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {

    private static InventoryDatabaseHelper helper;

    public static InventoryDatabaseHelper getInstance(Context context) {
        if (helper == null)
            helper = new InventoryDatabaseHelper(context);

        return helper;
    }

    private static final String DATABASE_NAME = "inventory.db";

    private static final int DATABASE_VERSION = 1;

    public InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private class InventoryTable {

        private static final String TABLE = "inventory";

        private static final String COL_ID = "_id";

        private static final String COL_ITEM = "inventory_item";

        private static final String COL_QTY = "item_qty";

        private static final String COL_LOCATION = "item_location";



    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table" + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " Integer primary key autoincrement, " +
                InventoryTable.COL_ITEM + " text, " +
                InventoryTable.COL_QTY + " int, " +
                InventoryTable.COL_LOCATION + " text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);

    }

    public void getALlItems(@NonNull ArrayList<InventoryItem> inventoryItem) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            do{
                long id = cursor.getLong(0);
                String item = cursor.getString(1);
                int qty = cursor.getInt(2);
                String location = cursor.getString(3);

                inventoryItem.add(new InventoryItem((int) id, item, qty, location));

            } while(cursor.moveToNext());
        }
        cursor.close();

    }

    public long add(InventoryItem inventoryItem) {
        SQLiteDatabase db = getReadableDatabase();

        ContentValues values = new ContentValues();

        values.put(InventoryTable.COL_ITEM, inventoryItem.getItemName());
        values.put(InventoryTable.COL_QTY, inventoryItem.getItemQuantity());
        values.put(InventoryTable.COL_LOCATION, inventoryItem.getItemLocation());

        long id = db.insert(InventoryTable.TABLE, null, values);
        inventoryItem.setItemId((int) id);

        return id;
    }

    public Boolean update(InventoryItem inventoryItem){
        SQLiteDatabase db = getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(InventoryTable.COL_ITEM, inventoryItem.getItemName());
        values.put(InventoryTable.COL_QTY, inventoryItem.getItemQuantity());
        values.put(InventoryTable.COL_LOCATION, inventoryItem.getItemLocation());

        int rowsUpdated = db.update(InventoryTable.TABLE, values, "_id = ?",
                new String[] {Long.toString(inventoryItem.getItemId())});

        return rowsUpdated > 0;

    }

    public Boolean delete(InventoryItem inventoryItem){

        SQLiteDatabase db = getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(InventoryTable.COL_ITEM, inventoryItem.getItemName());
        values.put(InventoryTable.COL_QTY, inventoryItem.getItemQuantity());
        values.put(InventoryTable.COL_LOCATION, inventoryItem.getItemLocation());

        int rowsDeleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " =?",
                new String[] {Long.toString(inventoryItem.getItemId())});

        return rowsDeleted > 0;

    }



}
